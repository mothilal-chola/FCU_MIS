# 🚌 Supaa Travels WhatsApp Chatbot & Conversational Commerce Engine

An interactive, enterprise-grade WhatsApp Chatbot and Conversational Commerce solution for **Supaa Travels**, faithfully designed and implemented based on the specifications in:
- [`Supaa Travels WhatsApp Chatbot Interactive Workflow.pdf`](file:///D:/Mothilal/AntiGravity_Projects/ChatBot/Supaa%20Travels%20WhatsApp%20Chatbot%20Interactive%20Workflow.pdf)
- [`ActualFlow.jpg`](file:///D:/Mothilal/AntiGravity_Projects/ChatBot/ActualFlow.jpg)
- [`Requirement.jpg`](file:///D:/Mothilal/AntiGravity_Projects/ChatBot/Requirement.jpg)

---

## 🌟 Interactive Preview & Simulator

To immediately experience the chatbot, open [`index.html`](file:///D:/Mothilal/AntiGravity_Projects/ChatBot/index.html) in your browser:

Double-click `index.html` or open via browser:
```
D:\Mothilal\AntiGravity_Projects\ChatBot\index.html
```

### ✨ Simulator Highlights:
1. **Pixel-Perfect WhatsApp Business Client**:
   - Official WhatsApp palette (`#075E54`, `#128C7E`, `#25D366`), message timestamps, delivery ticks (`✓✓`), and verified green badge.
   - Interactive Quick Reply pills and bus inventory cards.
   - Micro-animations for bot typing indicators and radar GPS pulses.
2. **Decision Tree Architecture Inspector**:
   - Live state monitor highlighting active nodes in real-time (`[Greeting]` → `[Extraction]` → `[Inventory]` → `[Checkout]` → `[Fulfillment]`).
   - Real-time NLP JSON entity extraction preview (`origin`, `destination`, `travel_date`, `passenger_count`).
3. **Interactive Payment Gateway Modal**:
   - Live UPI QR code generator (GPay, PhonePe, Paytm, BHIM) and Credit/Debit Card tab.
   - Interactive toggle for **Case A: Success (96%)** vs **Case B: Failed (4% with seat hold protection)**.
4. **Instant Boarding Pass & PDF E-Ticket**:
   - Official E-Ticket view with scannable QR boarding pass for bus door check-in, seat allocations (`L4, L5`), and 1-click print/download.
5. **Real-Time IoT Telematics GPS Map**:
   - Animated SVG live route map tracking Bus `TN-01-AB-4421` approaching Sriperumbudur Toll Plaza with live speed (68 km/h) and boarding ETA (25 mins).
6. **Support Desk CRM (Agent Fallback View)**:
   - Dedicated tab simulating the Central Support Executive Desk, showing live escalated tickets, forwarded WhatsApp chat history with zero context loss, and live response composer.

---

## 🗺️ Decision Tree Architecture Mapping

```
Customer Incoming Message ("Hi" / Request)
       │
       ▼
Intent Classification: Booking Intent Detected?
       ├─────────────────────────────────────────┐
       ▼                                         ▼
BRANCH A: Quick Reply Hub                 BRANCH B: Direct Booking Pipeline
(No NLP Intent Detected)                  (Fast-Track 5-Step Transaction Loop)
 1. 🚌 Book Bus Ticket                     1. Route, Date & Passengers Capture
 2. ✈️ Book Flight                         2. Live Inventory Query & Seat Selection
 3. 🔍 Track Booking                       3. 10-Minute Temporary Seat Lock
 4. ❌ Cancel & Refund                      4. Secure Payment Gateway (UPI / Cards)
 5. 👨‍💼 Speak to Agent                      5. Instant PDF Ticket & Boarding Pass
       │                                         │
       └─────────────────► Sub-Flows ◄───────────┘
                               │
       ┌───────────────────────┼────────────────────────┐
       ▼                       ▼                        ▼
SUPPORT BRANCH 02        SUPPORT BRANCH 03        SUPPORT BRANCH 04
PNR Telematics Tracking  Refund Rules & Cancel    Human Agent Fallback
• Bus No: TN-01-AB-4421  • Ticket Fare: ₹1,785    • Context-preserving
• Sriperumbudur          • 10% Fee: ₹178            handoff to CRM Desk
• ETA: 25 mins           • UPI Refund: ₹1,607
```

---

## 📁 Repository Structure

| File | Purpose |
| :--- | :--- |
| [`index.html`](file:///D:/Mothilal/AntiGravity_Projects/ChatBot/index.html) | Standalone interactive WhatsApp Business Web simulator & Decision Tree Inspector |
| [`styles.css`](file:///D:/Mothilal/AntiGravity_Projects/ChatBot/styles.css) | Custom Vanilla CSS design system with WhatsApp aesthetics and glassmorphic inspector |
| [`app.js`](file:///D:/Mothilal/AntiGravity_Projects/ChatBot/app.js) | Full client-side conversational state engine, NLP parser, and interactive modals |
| [`chatbot_engine.py`](file:///D:/Mothilal/AntiGravity_Projects/ChatBot/chatbot_engine.py) | Python backend microservice implementing WhatsApp Cloud API webhook handler |
| [`test_chatbot.py`](file:///D:/Mothilal/AntiGravity_Projects/ChatBot/test_chatbot.py) | `pytest` test suite with database fixtures, SARGable query tests, and calculation validations |
| [`Supaa Travels WhatsApp Chatbot Interactive Workflow.pdf`](file:///D:/Mothilal/AntiGravity_Projects/ChatBot/Supaa%20Travels%20WhatsApp%20Chatbot%20Interactive%20Workflow.pdf) | Original product specification & decision tree document |

---

## 🛠️ Python Backend Architecture & Standards Compliance

The Python engine ([`chatbot_engine.py`](file:///D:/Mothilal/AntiGravity_Projects/ChatBot/chatbot_engine.py)) strictly follows database engineering and query optimization guidelines:

1. **SARGable Queries & Explicit Column Selections**:
   - Zero usage of `SELECT *`. Every query explicitly defines its required projection:
     ```sql
     SELECT id, bus_name, bus_type, departure_time, arrival_time, available_seats, fare_per_pax
     FROM bus_inventory
     WHERE origin_code = :origin_code
       AND dest_code = :dest_code
       AND travel_date = :travel_date;
     ```
   - Indexed columns (`pnr`, `origin_code`, `dest_code`, `travel_date`) are never wrapped in non-SARGable functions.
2. **Explicit Parameterization**:
   - All queries use parameterized dictionaries (`:pnr`, `:origin_code`) preventing SQL injection and maximizing query plan reuse.
3. **Data Integrity & Atomic Transactions**:
   - Booking cancellations and refund dispatch execute in atomic transactions.
4. **Pytest Fixtures & Teardown**:
   - [`test_chatbot.py`](file:///D:/Mothilal/AntiGravity_Projects/ChatBot/test_chatbot.py) uses structured fixtures with clean in-memory database teardown.

---

## 🧪 Running Automated Tests

To run the unit test suite (when Python is configured in your environment):
```bash
pytest test_chatbot.py -v
```
All tests validate:
- Intent classification accuracy across all 8 branches
- SARGable search & index utilization
- 10% cancellation fee policy calculation (`₹1,785` &rarr; `₹178` fee &rarr; `₹1,607` refund)
- Telematics IoT telemetry coordinates retrieval
- Zero-context-loss agent escalation payload serialization
