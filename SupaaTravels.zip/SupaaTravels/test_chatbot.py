"""
Unit and Integration Test Suite for Supaa Travels Chatbot Engine
================================================================
Strictly adheres to pytest and database engineering policies:
- Clean pytest fixtures with explicit connection and rollback/teardown
- Validation of SARGable query execution and explicit column projections (no SELECT *)
- Full coverage of Decision Tree steps from Supaa Travels WhatsApp Workflow PDF
"""

import pytest
from typing import Generator
from chatbot_engine import (
    SupaaTravelsRepository,
    SupaaTravelsChatbotEngine,
    NLPParser,
    IntentType,
    BookingStatus,
    ExtractedEntities
)


@pytest.fixture
def repo() -> Generator[SupaaTravelsRepository, None, None]:
    """Provides an isolated in-memory test database repository with seed data."""
    repository = SupaaTravelsRepository(db_path=":memory:")
    yield repository
    # Clean teardown
    with repository._get_connection() as conn:
        conn.close()


@pytest.fixture
def chatbot(repo: SupaaTravelsRepository) -> SupaaTravelsChatbotEngine:
    """Instantiates chatbot engine wired to the test repository."""
    return SupaaTravelsChatbotEngine(repository=repo)


# ============================================================================
# NLP and Intent Classification Tests
# ============================================================================

class TestNLPAndIntentExtraction:
    """Verifies intent detection and entity parsing engine."""

    @pytest.mark.parametrize("input_phrase,expected_intent", [
        ("Hi, I need help.", IntentType.GREETING),
        ("Hello", IntentType.GREETING),
        ("Namaste, want to book", IntentType.BOOK_BUS),
        ("Chennai to Bangalore, 25 Oct, 2 passengers", IntentType.BOOK_BUS),
        ("Track SP774201", IntentType.TRACK_PNR),
        ("Where is my bus?", IntentType.TRACK_PNR),
        ("Cancel my ticket SP774201", IntentType.REFUND_CANCEL),
        ("I want a refund", IntentType.REFUND_CANCEL),
        ("I want to speak to an agent", IntentType.AGENT_HANDOFF),
        ("Human executive please", IntentType.AGENT_HANDOFF),
        ("1", IntentType.SELECT_OPTION),
        ("option 2", IntentType.SELECT_OPTION),
    ])
    def test_intent_classification(self, input_phrase: str, expected_intent: IntentType) -> None:
        detected = NLPParser.classify_intent(input_phrase)
        assert detected == expected_intent

    def test_entity_extraction_from_workflow_pdf(self) -> None:
        """
        Validates entity extraction from Slide 4 of the workflow PDF:
        Input: 'Chennai to Bangalore, 25 Oct, 2 passengers'
        Expected: origin='Chennai (MAA)', destination='Bangalore (BLR)', date='2026-10-25', count=2
        """
        sample_msg = "Chennai to Bangalore, 25 Oct, 2 passengers"
        entities: ExtractedEntities = NLPParser.extract_booking_entities(sample_msg)

        assert entities.origin_code == "MAA"
        assert entities.dest_code == "BLR"
        assert entities.passenger_count == 2
        assert entities.travel_date == "2026-10-25"

    def test_pnr_extraction(self) -> None:
        msg = "Track SP774201 live location"
        entities = NLPParser.extract_booking_entities(msg)
        assert entities.pnr == "SP774201"


# ============================================================================
# Database SARGable & Explicit Column Projection Tests
# ============================================================================

class TestDatabaseRepository:
    """Verifies database queries, indexes, and explicit column lists."""

    def test_sargable_bus_inventory_search(self, repo: SupaaTravelsRepository) -> None:
        """Ensures search uses indexed route codes and returns top 3 buses."""
        buses = repo.search_bus_inventory("MAA", "BLR", "2026-10-25")
        assert len(buses) == 3
        # Lowest fare first
        assert buses[0].fare_per_pax <= buses[1].fare_per_pax
        assert buses[0].name == "SRS Travels Non-A/C" or buses[0].fare_per_pax == 550

    def test_get_booking_by_pnr_with_passengers(self, repo: SupaaTravelsRepository) -> None:
        """Ensures booking lookup explicitly fetches booking and associated passengers without N+1."""
        booking = repo.get_booking_by_pnr("SP774201")
        assert booking is not None
        assert booking.pnr == "SP774201"
        assert booking.total_fare == 1785
        assert booking.status == BookingStatus.CONFIRMED
        assert len(booking.passengers) == 2
        assert booking.passengers[0].name == "Arun Kumar"
        assert booking.passengers[1].name == "Deepa Arun"
        assert booking.seats == ["L4", "L5"]

    def test_get_telematics_by_pnr(self, repo: SupaaTravelsRepository) -> None:
        """Ensures telematics GPS coordinates and ETA are retrieved accurately."""
        tele = repo.get_telematics_by_pnr("SP774201")
        assert tele is not None
        assert tele.bus_number == "TN-01-AB-4421"
        assert tele.eta_minutes == 25
        assert "Sriperumbudur" in tele.current_landmark
        assert tele.speed_kmh == 68

    def test_atomic_cancellation_and_status_update(self, repo: SupaaTravelsRepository) -> None:
        """Verifies atomic state transition from CONFIRMED to CANCELLED."""
        success, count = repo.cancel_booking_and_record_refund("SP774201")
        assert success is True
        assert count == 1

        # Verify updated status
        updated = repo.get_booking_by_pnr("SP774201")
        assert updated is not None
        assert updated.status == BookingStatus.CANCELLED


# ============================================================================
# End-to-End Chatbot Decision Tree Tests
# ============================================================================

class TestChatbotDecisionTreeWorkflow:
    """Verifies all 5 direct booking steps and 3 support sub-flows."""

    def test_step_01_greeting_hub(self, chatbot: SupaaTravelsChatbotEngine) -> None:
        resp = chatbot.process_incoming_message("+919876543210", "Hi, I need help.")
        assert resp.action_type == "QUICK_REPLY"
        assert "Welcome to Supaa Travels" in resp.text
        assert any("Book Bus Ticket" in btn["title"] for btn in resp.interactive_buttons)

    def test_step_02_and_03_route_capture_and_inventory(self, chatbot: SupaaTravelsChatbotEngine) -> None:
        resp = chatbot.process_incoming_message("+919876543210", "Chennai to Bangalore, 25 Oct, 2 passengers")
        assert resp.action_type == "INVENTORY_LIST"
        assert "Top 3 Buses" in resp.text
        assert "Supaa Volvo Multi-Axle" in resp.text
        assert len(resp.interactive_buttons) == 3

    def test_step_04_order_summary_and_fare(self, chatbot: SupaaTravelsChatbotEngine) -> None:
        resp = chatbot.process_incoming_message("+919876543210", "1")
        assert resp.action_type == "PAYMENT_GATEWAY"
        assert "Booking Order Summary" in resp.text
        assert "₹1,785" in resp.text
        assert "Held securely for 10 minutes" in resp.text

    def test_step_05_fulfillment_e_ticket(self, chatbot: SupaaTravelsChatbotEngine) -> None:
        resp = chatbot.step_05_fulfillment_e_ticket("SP774201")
        assert resp.action_type == "TICKET_FULFILLMENT"
        assert "Booking Confirmed" in resp.text
        assert "SP774201" in resp.text
        assert resp.document_attachment is not None
        assert resp.document_attachment["filename"] == "Supaa_Ticket_SP774201.pdf"

    def test_subflow_02_real_time_gps_tracking(self, chatbot: SupaaTravelsChatbotEngine) -> None:
        resp = chatbot.process_incoming_message("+919876543210", "Track SP774201")
        assert resp.action_type == "TELEMATICS_GPS"
        assert "Live Bus Location Update" in resp.text
        assert "TN-01-AB-4421" in resp.text
        assert "25 mins" in resp.text

    def test_subflow_03_refund_calculation_10_percent_policy(self, chatbot: SupaaTravelsChatbotEngine) -> None:
        """
        Validates refund calculation matching PDF slide 9:
        - Ticket fare: ₹1,785
        - Cancellation Fee (10%): ₹178
        - Refund Amount: ₹1,607 (Instant to UPI)
        """
        resp = chatbot.process_incoming_message("+919876543210", "Cancel my ticket SP774201")
        assert resp.action_type == "REFUND_QUOTE"
        assert "Ticket Fare: ₹1,785" in resp.text
        assert "Cancellation Fee (10%): ₹178" in resp.text
        assert "Refund Amount: ₹1,607 (Instant to UPI)" in resp.text

    def test_subflow_04_human_agent_handoff(self, chatbot: SupaaTravelsChatbotEngine) -> None:
        resp = chatbot.process_incoming_message("+919876543210", "I want to speak with an agent")
        assert resp.action_type == "AGENT_HANDOFF"
        assert "Forwarding your session to a Supaa Travels senior travel executive" in resp.text
