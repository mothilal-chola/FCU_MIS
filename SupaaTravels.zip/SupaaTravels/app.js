/**
 * Supaa Travels WhatsApp Chatbot Simulator
 * Core State Machine, Decision Tree Engine, and Interactive Workflows
 * Based on "Supaa Travels WhatsApp Chatbot Interactive Workflow.pdf"
 */

(function () {
  'use strict';

  // --- State Store ---
  const state = {
    currentStep: '1',
    currentBranch: 'Branch A: Quick Reply Hub',
    statusText: 'Transitioning from [Greeting] → [Service Selection]',
    entities: {
      origin: 'Chennai (MAA)',
      destination: 'Bangalore (BLR)',
      travel_date: '2026-10-25',
      passenger_count: 2,
      service_type: 'bus',
      pnr: null,
      hold_expires_at: null,
      selected_bus: null,
      total_fare: 1785
    },
    inventory: [
      {
        id: 1,
        name: 'Supaa Volvo Multi-Axle',
        departure: '10:30 PM',
        availableSeats: 8,
        farePerPax: 850,
        type: 'A/C Semi-Sleeper'
      },
      {
        id: 2,
        name: 'GreenLine A/C Sleeper',
        departure: '11:15 PM',
        availableSeats: 14,
        farePerPax: 720,
        type: 'A/C Sleeper'
      },
      {
        id: 3,
        name: 'SRS Travels Non-A/C',
        departure: '09:45 PM',
        availableSeats: 12,
        farePerPax: 550,
        type: 'Non-A/C Pushback'
      }
    ],
    booking: {
      pnr: 'SP774201',
      bookingId: 'STB-92841',
      busName: 'Supaa Volvo Multi-Axle',
      route: 'Chennai → Bangalore',
      boardingPoint: 'Koyambedu Omni Bus Stand (Pillar 14)',
      boardingTime: '10:15 PM',
      travelDate: '25 Oct 2026',
      seats: ['L4', 'L5'],
      passengers: [
        { name: 'Arun Kumar', age: 28, gender: 'M', seat: 'L4' },
        { name: 'Deepa Arun', age: 26, gender: 'F', seat: 'L5' }
      ],
      totalFare: 1785,
      cancellationFee: 178,
      refundAmount: 1607,
      status: 'NOT_BOOKED' // NOT_BOOKED, HELD, CONFIRMED, CANCELLED
    },
    chatHistory: [],
    agentHandoff: false
  };

  // --- DOM References ---
  const chatMessages = document.getElementById('chatMessages');
  const userInput = document.getElementById('userInput');
  const sendBtn = document.getElementById('sendBtn');
  const currentStatusText = document.getElementById('currentStatusText');
  const activeNodeTag = document.getElementById('activeNodeTag');
  const activeBranchTag = document.getElementById('activeBranchTag');
  const jsonEntityBox = document.getElementById('jsonEntityBox');
  const treeStepItems = document.querySelectorAll('.tree-step-item');
  const promptChips = document.querySelectorAll('.prompt-chip');

  // Modals
  const paymentModal = document.getElementById('paymentModal');
  const closePaymentModal = document.getElementById('closePaymentModal');
  const btnCancelPayment = document.getElementById('btnCancelPayment');
  const btnSubmitPayment = document.getElementById('btnSubmitPayment');

  const gpsModal = document.getElementById('gpsModal');
  const closeGpsModal = document.getElementById('closeGpsModal');

  const ticketModal = document.getElementById('ticketModal');
  const closeTicketModal = document.getElementById('closeTicketModal');
  const btnPrintTicket = document.getElementById('btnPrintTicket');
  const btnDownloadTicket = document.getElementById('btnDownloadTicket');

  // Views & Agent Desk
  const viewModeChat = document.getElementById('viewModeChat');
  const viewModeAgent = document.getElementById('viewModeAgent');
  const chatSection = document.getElementById('chatSection');
  const agentSection = document.getElementById('agentSection');
  const agentBadge = document.getElementById('agentBadge');
  const crmTranscript = document.getElementById('crmTranscript');
  const agentReplyInput = document.getElementById('agentReplyInput');
  const btnSendAgentReply = document.getElementById('btnSendAgentReply');
  const btnTakeOverChat = document.getElementById('btnTakeOverChat');
  const btnResolveTicket = document.getElementById('btnResolveTicket');
  const ticketSnippet = document.getElementById('ticketSnippet');

  // Scenario Buttons
  const btnRunFullBooking = document.getElementById('btnRunFullBooking');
  const btnRunTracking = document.getElementById('btnRunTracking');
  const btnRunRefund = document.getElementById('btnRunRefund');
  const btnRunHandoff = document.getElementById('btnRunHandoff');
  const btnResetChat = document.getElementById('btnResetChat');
  const themeToggle = document.getElementById('themeToggle');

  // --- Helpers ---
  function getTimeString() {
    const d = new Date();
    let hours = d.getHours();
    const minutes = d.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    return `${hours}:${minutes} ${ampm}`;
  }

  function updateEntityDisplay() {
    jsonEntityBox.textContent = JSON.stringify(state.entities, null, 2);
  }

  function setTreeState(stepNum, branchName, statusMessage, nodeLabel) {
    state.currentStep = stepNum;
    state.currentBranch = branchName;
    state.statusText = statusMessage;

    currentStatusText.innerHTML = statusMessage;
    activeNodeTag.textContent = nodeLabel;
    activeBranchTag.textContent = branchName;

    treeStepItems.forEach(item => {
      const step = item.getAttribute('data-step');
      if (step === String(stepNum)) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    updateEntityDisplay();
  }

  // Draw simple decorative QR Code matrix onto canvas
  function drawQrCode(canvasId, text) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);

    const gridSize = 21;
    const cellSize = Math.floor(w / gridSize);
    const offset = Math.floor((w - cellSize * gridSize) / 2);

    // Simple pseudo-random hash generator for authentic QR pattern
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
      hash = (hash << 5) - hash + text.charCodeAt(i);
      hash |= 0;
    }

    ctx.fillStyle = '#111b21';

    // Corner Finder Patterns
    function drawFinder(r, c) {
      for (let i = -3; i <= 3; i++) {
        for (let j = -3; j <= 3; j++) {
          const row = r + i;
          const col = c + j;
          const dist = Math.max(Math.abs(i), Math.abs(j));
          if (dist === 3 || dist === 0 || dist === 1) {
            ctx.fillRect(offset + col * cellSize, offset + row * cellSize, cellSize, cellSize);
          }
        }
      }
    }

    drawFinder(3, 3);
    drawFinder(3, gridSize - 4);
    drawFinder(gridSize - 4, 3);

    // Fill data grid
    for (let r = 0; r < gridSize; r++) {
      for (let c = 0; c < gridSize; c++) {
        if ((r <= 7 && c <= 7) || (r <= 7 && c >= gridSize - 8) || (r >= gridSize - 8 && c <= 7)) {
          continue; // skip finders
        }
        const bit = ((hash ^ (r * 19 + c * 29)) & 1) === 0;
        if (bit) {
          ctx.fillRect(offset + c * cellSize, offset + r * cellSize, cellSize, cellSize);
        }
      }
    }
  }

  // --- Chat Message Rendering ---
  function appendUserMessage(text) {
    const msg = document.createElement('div');
    msg.className = 'wa-message outgoing';
    msg.innerHTML = `
      <div class="msg-content">${escapeHtml(text)}</div>
      <div class="msg-footer">
        <span class="msg-timestamp">${getTimeString()}</span>
        <span class="msg-ticks">✓✓</span>
      </div>
    `;
    chatMessages.appendChild(msg);
    scrollChat();

    // Log to state & CRM transcript
    state.chatHistory.push({ sender: 'Customer', text, time: getTimeString() });
    updateCrmTranscript();
  }

  function appendBotMessage(htmlContent, callback) {
    // Show typing indicator first
    const typing = document.createElement('div');
    typing.className = 'wa-typing-indicator';
    typing.innerHTML = `
      <span class="typing-dot"></span>
      <span class="typing-dot"></span>
      <span class="typing-dot"></span>
    `;
    chatMessages.appendChild(typing);
    scrollChat();

    setTimeout(() => {
      if (typing.parentNode) {
        typing.remove();
      }

      const msg = document.createElement('div');
      msg.className = 'wa-message incoming';
      msg.innerHTML = `
        <div class="msg-content">${htmlContent}</div>
        <div class="msg-footer">
          <span class="msg-timestamp">${getTimeString()}</span>
        </div>
      `;
      chatMessages.appendChild(msg);
      scrollChat();

      // Log to history
      const textClean = htmlContent.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
      state.chatHistory.push({ sender: 'Supaa Bot', text: textClean, time: getTimeString() });
      updateCrmTranscript();

      if (callback) callback();
    }, 600);
  }

  function scrollChat() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function escapeHtml(string) {
    const div = document.createElement('div');
    div.innerText = string;
    return div.innerHTML;
  }

  // --- Step 01: Greeting & Quick Reply Hub ---
  function sendGreetingHub() {
    setTreeState(
      '1',
      'Branch A: Quick Reply Hub',
      'Transitioning from <strong>[Greeting]</strong> &rarr; <strong>[Service Selection]</strong>',
      'Step 01: Initiation'
    );

    const html = `
      👋 <strong>Welcome to Supaa Travels!</strong> How can we assist your trip today?
      <div class="wa-interactive-buttons">
        <button class="wa-btn-pill primary" data-action="book_bus">🚌 Book Bus Ticket</button>
        <button class="wa-btn-pill" data-action="book_flight">✈️ Book Flight</button>
        <button class="wa-btn-pill" data-action="track_pnr">🔍 Track Booking</button>
        <button class="wa-btn-pill" data-action="cancel_refund">❌ Cancel & Refund</button>
        <button class="wa-btn-pill" data-action="speak_agent">👨‍💼 Speak to Agent</button>
      </div>
    `;

    appendBotMessage(html);
  }

  // --- Step 02: Parameter Extraction Request ---
  function promptRouteDetails() {
    setTreeState(
      '2',
      'Branch B: Direct Booking Pipeline',
      'Transitioning to <strong>[Parameter Extraction]</strong> &rarr; Awaiting Route & Date',
      'Step 02: Extraction'
    );

    const html = `
      Great! Please reply with your route and date:<br><br>
      <strong>From - To - Date - Passengers</strong><br>
      <em>e.g., Chennai to Bangalore, 25 Oct, 2 pax</em>
    `;

    appendBotMessage(html);
  }

  // --- Step 03: Inventory Query & Service Selection ---
  function showBusInventory() {
    setTreeState(
      '3',
      'Branch B: Direct Booking Pipeline',
      'Tree Status: Invoking <strong>[Inventory Search API]</strong> via Webhook &rarr; Temporary Lock',
      'Step 03: Inventory Selection'
    );

    state.entities.origin = 'Chennai (MAA)';
    state.entities.destination = 'Bangalore (BLR)';
    state.entities.travel_date = '2026-10-25';
    state.entities.passenger_count = 2;
    state.entities.hold_expires_at = new Date(Date.now() + 10 * 60 * 1000).toISOString();
    updateEntityDisplay();

    let cardsHtml = `
      🔍 <strong>Top 3 Buses (${state.entities.origin} &rarr; ${state.entities.destination}):</strong>
      <div class="bus-card-list">
    `;

    state.inventory.forEach(bus => {
      cardsHtml += `
        <div class="bus-item-card" data-bus-id="${bus.id}">
          <div class="bus-card-top">
            <span class="bus-number-badge">${bus.id}</span>
            <span class="bus-name-title">${bus.name}</span>
            <span class="bus-fare">₹${bus.farePerPax}</span>
          </div>
          <div class="bus-details-meta">
            <span>🕒 ${bus.departure} &bull; ${bus.type}</span>
            <span class="seats-badge">🟢 ${bus.availableSeats} Seats Left</span>
          </div>
        </div>
      `;
    });

    cardsHtml += `
      </div>
      <div style="margin-top: 8px; font-size: 0.8rem; color: #54656f;">
        <em>Reply with <strong>1</strong>, <strong>2</strong>, or <strong>3</strong> to select.</em>
      </div>
      <div class="wa-interactive-buttons">
        <button class="wa-btn-pill primary" data-action="select_bus_1">1️⃣ Supaa Volvo (₹850)</button>
        <button class="wa-btn-pill" data-action="select_bus_2">2️⃣ GreenLine A/C (₹720)</button>
        <button class="wa-btn-pill" data-action="select_bus_3">3️⃣ SRS Non-A/C (₹550)</button>
      </div>
    `;

    appendBotMessage(cardsHtml);
  }

  // --- Step 04: Order Summary & Checkout ---
  function showOrderSummary(busId) {
    const selectedBus = state.inventory.find(b => b.id === Number(busId)) || state.inventory[0];
    state.entities.selected_bus = selectedBus.name;
    state.booking.busName = selectedBus.name;
    state.booking.status = 'HELD';

    // Fare calculation: ₹850 * 2 = ₹1700 + ₹85 GST/charges = ₹1785 (matches PDF slide 6)
    const baseFare = selectedBus.farePerPax * 2;
    const taxes = Math.round(baseFare * 0.05);
    const total = baseFare + taxes;
    state.booking.totalFare = total;
    state.entities.total_fare = total;

    setTreeState(
      '4',
      'Branch B: Direct Booking Pipeline',
      'Tree Status: Advancing to <strong>[Checkout Initialization]</strong> &bull; Awaiting Payment Webhook',
      'Step 04: Checkout'
    );

    const html = `
      📋 <strong>Booking Order Summary:</strong>
      <div class="summary-box">
        <div class="summary-row"><span>Bus:</span> <strong>${selectedBus.name}</strong></div>
        <div class="summary-row"><span>Route:</span> Chennai &rarr; Bangalore</div>
        <div class="summary-row"><span>Pax:</span> Arun (28M), Deepa (26F)</div>
        <div class="summary-row"><span>Seats:</span> L4, L5 &bull; <small style="color:#d97706">Held for 10 mins</small></div>
        <div class="summary-row total"><span>Total Amount:</span> <span style="color:#047857">₹${total.toLocaleString('en-IN')}</span></div>
      </div>
      <div class="wa-interactive-buttons">
        <button class="wa-btn-pill primary" data-action="open_payment_modal">
          💳 Pay ₹${total.toLocaleString('en-IN')} via UPI / Cards
        </button>
      </div>
    `;

    appendBotMessage(html);
  }

  // --- Step 05: Confirmation & Instant PDF Boarding Pass ---
  function confirmBookingSuccess() {
    state.booking.status = 'CONFIRMED';
    state.entities.pnr = state.booking.pnr;

    setTreeState(
      '5',
      'Branch B: Terminal State',
      'Tree Status: <strong>Complete [Booking Done] &rarr; End State Reached</strong>',
      'Step 05: Fulfillment'
    );

    const html = `
      ✅ <strong>Booking Confirmed!</strong><br>
      PNR: <strong>${state.booking.pnr}</strong> &bull; ID: ${state.booking.bookingId}<br>
      Boarding: <strong>${state.booking.boardingPoint}</strong> (${state.booking.boardingTime})<br>
      
      <div class="doc-attachment-card" data-action="view_pdf_ticket">
        <div class="doc-pdf-icon">
          <span>PDF</span>
        </div>
        <div class="doc-info">
          <div class="doc-title">Supaa_Ticket_${state.booking.pnr}.pdf</div>
          <div class="doc-sub">184 KB &bull; Tap to view Boarding Pass & QR</div>
        </div>
      </div>

      <div class="wa-interactive-buttons">
        <button class="wa-btn-pill" data-action="track_pnr">📍 Track Bus</button>
        <button class="wa-btn-pill" data-action="cancel_refund">❌ Cancel Ticket</button>
      </div>
    `;

    appendBotMessage(html);
  }

  // Handle Payment Failure / Retry
  function handlePaymentFailure() {
    setTreeState(
      '4',
      'Branch B: Direct Booking Pipeline',
      'Payment Verification: <strong>CASE B: FAILED (4%)</strong> &bull; Protected reserved seat inventory',
      'Step 04: Payment Retry'
    );

    const html = `
      ⚠️ <strong>Payment Failed or Interrupted</strong><br>
      Your bank could not complete the transaction. Don't worry, your selected seats (L4, L5) are still safely held for the next 8 minutes.<br>
      <div class="wa-interactive-buttons">
        <button class="wa-btn-pill primary" data-action="open_payment_modal">🔄 Retry Payment (₹1,785)</button>
        <button class="wa-btn-pill" data-action="speak_agent">👨‍💼 Need Help with Payment?</button>
      </div>
    `;

    appendBotMessage(html);
  }

  // --- Sub-Flow 02: Real-time Telematics GPS Tracking ---
  function showLiveTracking() {
    setTreeState(
      'track',
      'Support Sub-Flow | Branch 02',
      'Tree Status: <strong>[Query Handled] &rarr; Self-Service Issue Resolved</strong> (Telematics Sync: 400ms)',
      'Sub-Flow 02: Live GPS'
    );

    const html = `
      📍 <strong>Live Bus Location Update:</strong><br>
      • Bus No: <strong>TN-01-AB-4421</strong><br>
      • Status: <strong>On Time (Approaching Sriperumbudur)</strong><br>
      • ETA at Boarding: <strong>10:15 PM (25 mins)</strong><br>

      <div class="telematics-preview-card" data-action="open_gps_modal" style="cursor: pointer;">
        <div class="tele-header">
          <span class="tele-badge">🟢 IoT Telematics Active</span>
          <small style="color: #94a3b8">Speed: 68 km/h</small>
        </div>
        <div class="tele-text">
          Vehicle is currently passing Sriperumbudur Toll Plaza on NH-48. Distance to Koyambedu: 28 km.
        </div>
      </div>

      <div class="wa-interactive-buttons">
        <button class="wa-btn-pill primary" data-action="open_gps_modal">🧭 Open Live GPS Map</button>
        <button class="wa-btn-pill" data-action="menu_home">🏠 Main Menu</button>
      </div>
    `;

    appendBotMessage(html);
  }

  // --- Sub-Flow 03: Refund & Cancellation ---
  function showCancellationBreakdown() {
    setTreeState(
      'refund',
      'Support Sub-Flow | Branch 03',
      'Tree Status: <strong>Controlled Exception Routing &rarr; Policy Breakdown</strong>',
      'Sub-Flow 03: Cancellation'
    );

    const html = `
      <strong>Cancellation Policy Breakdown:</strong><br>
      • Ticket Fare: <strong>₹1,785</strong><br>
      • Cancellation Fee (10%): <strong>₹178</strong><br>
      • Refund Amount: <strong>₹1,607 (Instant to UPI)</strong><br>
      
      <div class="wa-interactive-buttons">
        <button class="wa-btn-pill" data-action="confirm_cancel_ticket" style="color: #ef4444; border-color: #ef4444;">
          Confirm Cancel
        </button>
        <button class="wa-btn-pill" data-action="speak_agent">Speak to Agent</button>
      </div>
    `;

    appendBotMessage(html);
  }

  function confirmTicketCancelled() {
    state.booking.status = 'CANCELLED';

    setTreeState(
      'refund',
      'Support Sub-Flow | Branch 03',
      'Tree Status: <strong>Automated Refund API Invoked &bull; Reverse Transfer Complete</strong>',
      'Sub-Flow 03: Refund Sent'
    );

    const html = `
      ✅ <strong>Cancellation & Refund Processed Successfully</strong><br><br>
      • PNR: <strong>${state.booking.pnr}</strong> has been cancelled.<br>
      • Refund of <strong>₹1,607</strong> has been initiated back to your source UPI ID (arun@okhdfcbank).<br>
      • Reverse Webhook UTR: <strong>UTR-9821839210</strong> (Instant transfer completed).<br><br>
      Thank you for choosing Supaa Travels. We hope to serve you again soon!
      <div class="wa-interactive-buttons">
        <button class="wa-btn-pill primary" data-action="menu_home">🏠 Book Another Journey</button>
      </div>
    `;

    appendBotMessage(html);
  }

  // --- Sub-Flow 04: Human Agent Handoff ---
  function triggerAgentHandoff() {
    state.agentHandoff = true;

    setTreeState(
      'agent',
      'Support Sub-Flow | Branch 04',
      'Tree Status: <strong>Escalation to Live Human Agent Desk &bull; Full Context Forwarded</strong>',
      'Sub-Flow 04: Agent Handoff'
    );

    agentBadge.style.display = 'inline-block';
    ticketSnippet.textContent = 'Customer requested live support assistance for ticket ' + state.booking.pnr;

    const html = `
      👨‍💼 <strong>Connecting you to a Live Travel Specialist...</strong><br><br>
      Your chat transcript and booking details (PNR: ${state.booking.pnr}) have been transferred to our Central Support Desk with zero context loss.<br><br>
      An executive will message you here in WhatsApp shortly.
    `;

    appendBotMessage(html, () => {
      // Auto switch or alert user about CRM Desk tab
      setTimeout(() => {
        agentBadge.classList.add('pulse');
      }, 500);
    });
  }

  // --- CRM Desk Sync ---
  function updateCrmTranscript() {
    if (!crmTranscript) return;
    crmTranscript.innerHTML = '';
    state.chatHistory.forEach(item => {
      const row = document.createElement('div');
      let typeClass = 'bot';
      if (item.sender === 'Customer') typeClass = 'customer';
      else if (item.sender === 'Agent Executive') typeClass = 'agent';

      row.className = `crm-msg-row ${typeClass}`;
      row.innerHTML = `
        <div style="font-size: 0.7rem; font-weight: 700; margin-bottom: 2px; opacity: 0.8;">${item.sender} &bull; ${item.time}</div>
        <div>${escapeHtml(item.text)}</div>
      `;
      crmTranscript.appendChild(row);
    });
    crmTranscript.scrollTop = crmTranscript.scrollHeight;
  }

  // --- NLP & Intent Routing Engine ---
  function processUserText(rawText) {
    const text = rawText.trim();
    if (!text) return;

    appendUserMessage(text);
    userInput.value = '';

    const lower = text.toLowerCase();

    // 1. Direct Booking / Parameter Extraction phrases (Slide 4)
    // Matches patterns like "Chennai to Bangalore, 25 Oct, 2 passengers", "chennai to blr", "book bus from chennai to bangalore"
    if (lower.includes('to') && (lower.includes('chennai') || lower.includes('bangalore') || lower.includes('coimbatore') || lower.includes('oct') || lower.includes('passenger') || lower.includes('pax'))) {
      extractEntitiesFromText(text);
      showBusInventory();
      return;
    }

    // 2. Bus selection numbers ("1", "2", "3")
    if (text === '1' || lower.includes('supaa') || lower.includes('option 1')) {
      showOrderSummary(1);
      return;
    }
    if (text === '2' || lower.includes('greenline') || lower.includes('option 2')) {
      showOrderSummary(2);
      return;
    }
    if (text === '3' || lower.includes('srs') || lower.includes('option 3')) {
      showOrderSummary(3);
      return;
    }

    // 3. Tracking queries
    if (lower.includes('track') || lower.includes('status') || lower.includes('sp774201') || lower.includes('where is my bus')) {
      showLiveTracking();
      return;
    }

    // 4. Cancellation queries
    if (lower.includes('cancel') || lower.includes('refund')) {
      showCancellationBreakdown();
      return;
    }

    // 5. Agent handoff queries
    if (lower.includes('agent') || lower.includes('human') || lower.includes('executive') || lower.includes('help desk') || lower.includes('talk to someone')) {
      triggerAgentHandoff();
      return;
    }

    // 6. Direct Book Bus request
    if (lower.includes('book bus') || lower.includes('bus ticket') || lower.includes('bus')) {
      promptRouteDetails();
      return;
    }

    // 7. General greeting or fallback -> Greeting Hub
    sendGreetingHub();
  }

  function extractEntitiesFromText(text) {
    // Default extraction matching PDF slide 4
    let origin = 'Chennai (MAA)';
    let destination = 'Bangalore (BLR)';
    let date = '2026-10-25';
    let pax = 2;

    const lower = text.toLowerCase();
    if (lower.includes('coimbatore')) destination = 'Coimbatore (CJB)';
    if (lower.includes('madurai')) destination = 'Madurai (IXM)';

    const paxMatch = text.match(/(\d+)\s*(?:passenger|pax|people|seats)/i);
    if (paxMatch) {
      pax = parseInt(paxMatch[1], 10);
    }

    state.entities.origin = origin;
    state.entities.destination = destination;
    state.entities.travel_date = date;
    state.entities.passenger_count = pax;
    updateEntityDisplay();
  }

  // --- Interactive Click Handler Delegation ---
  document.addEventListener('click', function (e) {
    const target = e.target.closest('[data-action], [data-bus-id], [data-msg]');
    if (!target) return;

    // Prompt Chips at bottom of phone
    if (target.dataset.msg) {
      processUserText(target.dataset.msg);
      return;
    }

    // Bus Cards click
    if (target.dataset.busId) {
      showOrderSummary(target.dataset.busId);
      return;
    }

    const action = target.dataset.action;
    switch (action) {
      case 'book_bus':
        appendUserMessage('🚌 Book Bus Ticket');
        setTimeout(promptRouteDetails, 300);
        break;

      case 'book_flight':
        appendUserMessage('✈️ Book Flight');
        appendBotMessage('✈️ Flight search is ready! Please enter: Origin - Destination - Date (e.g. MAA to DEL, 28 Oct).');
        break;

      case 'track_pnr':
        appendUserMessage('Track SP774201');
        setTimeout(showLiveTracking, 300);
        break;

      case 'cancel_refund':
        appendUserMessage('Cancel my ticket SP774201');
        setTimeout(showCancellationBreakdown, 300);
        break;

      case 'speak_agent':
        appendUserMessage('Speak to Human Agent');
        setTimeout(triggerAgentHandoff, 300);
        break;

      case 'select_bus_1':
        appendUserMessage('1');
        showOrderSummary(1);
        break;

      case 'select_bus_2':
        appendUserMessage('2');
        showOrderSummary(2);
        break;

      case 'select_bus_3':
        appendUserMessage('3');
        showOrderSummary(3);
        break;

      case 'open_payment_modal':
        document.getElementById('modalBusName').textContent = state.booking.busName;
        document.getElementById('modalPaxSeats').textContent = `Arun (28M), Deepa (26F) • Seats ${state.booking.seats.join(', ')}`;
        paymentModal.classList.add('active');
        drawQrCode('upiQrCanvas', `upi://pay?pa=supaapay@hdfcbank&pn=SupaaTravels&am=${state.booking.totalFare}&tn=PNR_SP774201`);
        break;

      case 'view_pdf_ticket':
        ticketModal.classList.add('active');
        drawQrCode('ticketQrCanvas', `SUPAA_TICKET|PNR:${state.booking.pnr}|PAX:2|SEAT:L4,L5`);
        break;

      case 'open_gps_modal':
        gpsModal.classList.add('active');
        break;

      case 'confirm_cancel_ticket':
        appendUserMessage('Confirm Cancel Ticket SP774201');
        setTimeout(confirmTicketCancelled, 400);
        break;

      case 'menu_home':
        appendUserMessage('Hi, I need help');
        setTimeout(sendGreetingHub, 300);
        break;
    }
  });

  // --- Send Button and Enter Key ---
  sendBtn.addEventListener('click', () => processUserText(userInput.value));
  userInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      processUserText(userInput.value);
    }
  });

  // --- Modals Logic ---
  closePaymentModal.addEventListener('click', () => paymentModal.classList.remove('active'));
  btnCancelPayment.addEventListener('click', () => paymentModal.classList.remove('active'));

  btnSubmitPayment.addEventListener('click', () => {
    paymentModal.classList.remove('active');
    const outcome = document.querySelector('input[name="payOutcome"]:checked').value;

    appendUserMessage(`💳 Payment Authorized: ₹${state.booking.totalFare.toLocaleString('en-IN')}`);

    if (outcome === 'success') {
      setTimeout(confirmBookingSuccess, 600);
    } else {
      setTimeout(handlePaymentFailure, 600);
    }
  });

  // Payment method tabs
  const payTabs = document.querySelectorAll('.pay-tab');
  payTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      payTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const targetTab = tab.dataset.tab;
      document.getElementById('tabContentUpi').style.display = targetTab === 'upi' ? 'block' : 'none';
      document.getElementById('tabContentCard').style.display = targetTab === 'card' ? 'block' : 'none';
    });
  });

  // GPS Modal
  closeGpsModal.addEventListener('click', () => gpsModal.classList.remove('active'));

  // Ticket Modal
  closeTicketModal.addEventListener('click', () => ticketModal.classList.remove('active'));
  btnPrintTicket.addEventListener('click', () => {
    window.print();
  });
  btnDownloadTicket.addEventListener('click', () => {
    alert('📥 Downloading Supaa_Ticket_SP774201.pdf (184 KB)... Download Complete!');
  });

  // --- View Switcher: WhatsApp Simulator vs Agent Desk CRM ---
  viewModeChat.addEventListener('click', () => {
    viewModeChat.classList.add('active');
    viewModeAgent.classList.remove('active');
    chatSection.style.display = 'flex';
    document.querySelector('.sidebar-inspector').style.display = 'flex';
    agentSection.style.display = 'none';
  });

  viewModeAgent.addEventListener('click', () => {
    viewModeAgent.classList.add('active');
    viewModeChat.classList.remove('active');
    chatSection.style.display = 'none';
    document.querySelector('.sidebar-inspector').style.display = 'none';
    agentSection.style.display = 'block';
    agentBadge.style.display = 'none';
    updateCrmTranscript();
  });

  // CRM Agent Controls
  btnSendAgentReply.addEventListener('click', () => {
    const text = agentReplyInput.value.trim();
    if (!text) return;
    state.chatHistory.push({ sender: 'Agent Executive', text, time: getTimeString() });
    updateCrmTranscript();
    agentReplyInput.value = '';

    // Also send into customer chat as verified human reply
    const html = `
      👨‍💼 <strong>Supaa Support Executive (Live):</strong><br>
      ${escapeHtml(text)}
    `;
    const msg = document.createElement('div');
    msg.className = 'wa-message incoming';
    msg.innerHTML = `
      <div class="msg-content">${html}</div>
      <div class="msg-footer">
        <span class="msg-timestamp">${getTimeString()}</span>
      </div>
    `;
    chatMessages.appendChild(msg);
    scrollChat();
  });

  btnTakeOverChat.addEventListener('click', () => {
    agentReplyInput.value = 'Hello Arun, I am Rahul from Supaa Support. I have your PNR SP774201 on my screen. How may I assist you with your journey today?';
    agentReplyInput.focus();
  });

  btnResolveTicket.addEventListener('click', () => {
    alert('✅ Ticket #SUP-9842 marked as Resolved. Customer feedback survey dispatched.');
    viewModeChat.click();
  });

  // --- Scenario Quick-Launch Buttons ---
  btnRunFullBooking.addEventListener('click', () => {
    resetChat();
    appendUserMessage('Chennai to Bangalore, 25 Oct, 2 passengers');
    setTimeout(() => {
      extractEntitiesFromText('Chennai to Bangalore, 25 Oct, 2 passengers');
      showBusInventory();
    }, 400);
  });

  btnRunTracking.addEventListener('click', () => {
    appendUserMessage('Track SP774201');
    setTimeout(showLiveTracking, 400);
  });

  btnRunRefund.addEventListener('click', () => {
    appendUserMessage('Cancel my ticket SP774201');
    setTimeout(showCancellationBreakdown, 400);
  });

  btnRunHandoff.addEventListener('click', () => {
    appendUserMessage('I want to speak with an executive');
    setTimeout(triggerAgentHandoff, 400);
  });

  function resetChat() {
    chatMessages.innerHTML = `
      <div class="system-security-banner">
        <span class="lock-icon">🔒</span> Messages are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them.
      </div>
      <div class="chat-day-divider">
        <span>TODAY</span>
      </div>
    `;
    state.chatHistory = [];
    state.booking.status = 'NOT_BOOKED';
    sendGreetingHub();
  }

  btnResetChat.addEventListener('click', resetChat);

  // Theme toggle
  themeToggle.addEventListener('click', () => {
    const isLight = document.body.getAttribute('data-theme') === 'light';
    if (isLight) {
      document.body.removeAttribute('data-theme');
    } else {
      document.body.setAttribute('data-theme', 'light');
    }
  });

  // --- Initial Launch ---
  sendGreetingHub();
})();
